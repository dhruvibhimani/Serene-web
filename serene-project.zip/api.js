const API_BASE_URL = 'http://localhost:3000/api';

// Helper function for API calls
export async function apiRequest(endpoint, method = 'GET', body = null) {
  const options = {
    method,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': localStorage.getItem('token') ? `Bearer ${localStorage.getItem('token')}` : ''
    },
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'Something went wrong');
  }

  return data;
}

// Auth functions
export async function registerUser(userData) {
  return apiRequest('/users/register', 'POST', userData);
}

export async function loginUser(credentials) {
  return apiRequest('/users/login', 'POST', credentials);
}

// User functions
export async function getCurrentUser() {
  return apiRequest('/users/me');
}

// Emergency contacts functions
export async function addEmergencyContact(contactEmail) {
  return apiRequest('/users/emergency-contacts', 'POST', { contactEmail });
}