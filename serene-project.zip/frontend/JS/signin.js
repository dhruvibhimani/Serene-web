// Google Sign In (Mockup for now)
import { loginUser } from './api';
function signInWithGoogle() {
  alert("Google Sign In is currently under development.");
}

// Email Sign In
document.getElementById('signin-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  alert(`Welcome back, ${email}!`);
  window.location.href = "index.html";
});

document.getElementById('signin-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  try {
    const { token, user } = await loginUser({ email, password });
    
    // Store token and user data
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    
    // Redirect to dashboard
    window.location.href = '/dashboard.html';
  } catch (error) {
    alert(error.message);
  }
});
